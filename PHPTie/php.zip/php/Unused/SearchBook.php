<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Welcome to Speaker Curation Interface</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="favicon.png">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <div class="page home-page">
      <!-- Main Navbar-->
        <?php include("Includes/TopStrip.php"); ?>
      <div class="page-content d-flex align-items-stretch">
        <!-- Side Navbar -->
         <?php include("Includes/Sidebar.php"); ?>

        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Search</h2>
            </div>
          </header>
          <!-- Dashboard Counts Section-->
          <section class="dashboard-counts no-padding-bottom">
            <div class="container-fluid">
              <div class="row bg-white has-shadow">
                
                <!--  Work Start here -->
				   <!-- include javascript and css files for the EditableGrid library -->
					<script src="editablegrid/editablegrid.js"></script>
					
					<link rel="stylesheet" href="editablegrid/editablegrid.css" type="text/css" media="screen">
					<!-- include javascript and css files for jQuery, needed for the datepicker and autocomplete extensions -->
					<script src="editablegrid/jquery/jquery-1.6.4.min.js" ></script>
					<script src="editablegrid/jquery/jquery-ui-1.8.16.custom.min.js" ></script>

					<link rel="stylesheet" href="editablegrid/jquery/jquery-ui-1.8.16.custom.css" type="text/css" media="screen">
					
					<!-- include javascript and css files for the autocomplete extension -->
					<script src="editablegrid/autocomplete/autocomplete.js" ></script>
					<link rel="stylesheet" href="editablegrid/autocomplete/autocomplete.css" type="text/css" media="screen">
<script src="demo.js" ></script>
		<link rel="stylesheet" type="text/css" href="demo.css" media="screen"/>
		<!-- [DO NOT DEPLOY] -->
		<!-- [DO NOT DEPLOY] --><!-- [DO NOT DEPLOY] --> <?php if (isset($_GET['attach'])) { ?><script type="text/javascript">window.onload = function() { editableGrid.onloadHTML("htmlgrid"); } </script> <?php } ?>	
               		<div id="wrap">
					
		
			<!-- Feedback message zone -->
			<div id="message"></div>

			<!--  Number of rows per page and bars in chart -->
			<div id="pagecontrol">
				<label for="pagecontrol">Rows per page: </label>
				<select id="pagesize" name="pagesize">
					<option value="5">5</option>
					<option value="10">10</option>
					<option value="15">15</option>
					<option value="20">20</option>
					<option value="25">25</option>
					<option value="30">30</option>
					<option value="40">40</option>
					<option value="50">50</option>
				</select>
				&nbsp;&nbsp;
				<label for="barcount">Bars in chart: </label>
				<select id="barcount" name="barcount">
					<option value="5">5</option>
					<option value="10">10</option>
					<option value="15">15</option>
					<option value="20">20</option>
					<option value="25">25</option>
					<option value="30">30</option>
					<option value="40">40</option>
					<option value="50">50</option>
				</select>	
			</div>
		
			<!-- Grid filter -->
			<label for="filter">Filter :</label>
			<input type="text" id="filter"/>
		
			<!-- Grid contents -->
			<div id="tablecontent"></div>
			<!-- [DO NOT DEPLOY] --> <?php
 include("ResponciveTableBootstrap.html"); 
 if (isset($_GET['attach'])) include("htmlgrid.html"); ?>	
		
			<!-- Paginator control -->
			<div id="paginator"></div>
		
			<!-- Edition zone (to demonstrate the "fixed" editor mode) -->
			<div id="edition"></div>
			
			<!-- Charts zone -->
			<div id="barchartcontent"></div>
			<div id="piechartcontent"></div>
			
		</div>





             
               
                   <!-- Work End here -->
             
               
                
              </div>
            </div>
          </section>
          
         
          <!-- Client Section-->
          <section class="client no-padding-top">
            <div class="container-fluid">
              <div class="row">  
              </div>
            </div>
          </section>        
      

          <!-- Page Footer-->
          <?php include("Includes/BottomStrip.php"); ?>

        </div>
      </div>
    </div>
    <!-- Javascript files-->
    
  </body>
</html>