<?php

//My SQL Server Connection 
$mysql_hostname = "localhost";
$mysql_user = "root";
$mysql_password = "";
$mysql_database = "curationdb";
$prefix = "";
$conn = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password,$mysql_database) or die("Could not connect database");
//mysql_select_db($mysql_database) or die("Could not select database");


// SQL Server Database connection
//$serverName = "184.168.194.78";
//$connectionInfo = array( "Database"=>"bizacumen_Analyst_vizag", "UID"=>"new_sisuser", "PWD"=>"sisindia959$");
//$conn = sqlsrv_connect( $serverName, $connectionInfo) OR die ('broke:' .sqlsrv_errors());
?>