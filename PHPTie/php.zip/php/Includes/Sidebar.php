<nav class="side-navbar">
          <!-- Sidebar Header-->
           <div class="sidebar-header d-flex align-items-center">
	   <?php if (trim($_SESSION['SESS_FIRST_NAME']) !== "")
	     	{ ?>
            <!--<div class="avatar"><img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>-->
            <div class="title">
	     
              <h1 class="h4"><?php echo(Trim($_SESSION['SESS_FIRST_NAME']));?></h1>
              <p><?php echo(Trim($_SESSION['SESS_DOMAIN']));?></p>
            </div>
	      <?php } ?>
          </div>
          <!-- Sidebar Navidation Menus-->
          <ul class="list-unstyled">
            <li > <a href="Home.php"><i class="icon-home"></i>Home</a></li>
            <!--li><a href="#dashvariants" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Search </a>
              <ul id="dashvariants" class="collapse list-unstyled">
                <li><a href="#">Page</a></li>
                <li><a href="#">Page</a></li>
                <li><a href="#">Page</a></li>
                <li><a href="#">Page</a></li>
              </ul>
            </li-->
			 <li class="active"> <a href="SearchMulti.php"> <i class="icon-padnote"></i>Search </a></li>    
            <li> <a href="Download.php"> <i class="icon-grid"></i>Download </a></li>           
            <li> <a href="Index.php"> <i class="icon-interface-windows"></i>Logout</a></li>
          </ul>
          
        </nav>