﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Data.OleDb;
using iTextSharp.text.pdf;
using iTextSharp.text;

namespace PdfStampingSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }
        public static DialogResult InputBox(string title, string promptText, ref string value)
        {
            Form form = new Form();
            Label label = new Label();
            TextBox textBox = new TextBox();
            Button buttonOk = new Button();
            Button buttonCancel = new Button();

            form.Text = title;
            label.Text = promptText;
            textBox.Text = value;

            buttonOk.Text = "OK";
            buttonCancel.Text = "Cancel";
            buttonOk.DialogResult = DialogResult.OK;
            buttonCancel.DialogResult = DialogResult.Cancel;

            label.SetBounds(9, 20, 372, 13);
            textBox.SetBounds(12, 36, 372, 20);
            buttonOk.SetBounds(228, 72, 75, 23);
            buttonCancel.SetBounds(309, 72, 75, 23);

            label.AutoSize = true;
            textBox.Anchor = textBox.Anchor | AnchorStyles.Right;
            buttonOk.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;

            form.ClientSize = new Size(396, 107);
            form.Controls.AddRange(new Control[] { label, textBox, buttonOk, buttonCancel });
            form.ClientSize = new Size(Math.Max(300, label.Right + 10), form.ClientSize.Height);
            form.FormBorderStyle = FormBorderStyle.FixedDialog;
            form.StartPosition = FormStartPosition.CenterScreen;
            form.MinimizeBox = false;
            form.MaximizeBox = false;
            form.AcceptButton = buttonOk;
            form.CancelButton = buttonCancel;

            DialogResult dialogResult = form.ShowDialog();
            value = textBox.Text;
            return dialogResult;
        }
        public String StampPDFReport(String TransactionId, String DateDelivered, String Licensee, String Company, String MCPReport)
        {
            try
            {
                PdfReader pdfReader = new PdfReader (MCPReport);
                //create stream of filestream or memorystream etc. to create output file
                //  FileStream stream = new FileStream(Server.MapPath("Output") + "/output1.pdf", FileMode.OpenOrCreate);
                FileStream stream = new FileStream( MCPReport.Replace(".pdf","out.pdf"), FileMode.OpenOrCreate);
                //create pdfstamper object which is used to add addtional content to source pdf file
                PdfStamper pdfStamper = new PdfStamper(pdfReader, stream);
                //iterate through all pages in source pdf
                for (int pageIndex = 1; pageIndex <= pdfReader.NumberOfPages; pageIndex++)
                {
                    //Rectangle class in iText represent geomatric representation... in this case, rectanle object would contain page geomatry
                    iTextSharp.text.Rectangle pageRectangle = pdfReader.GetPageSizeWithRotation(pageIndex);
                    //pdfcontentbyte object contains graphics and text content of page returned by pdfstamper
                    PdfContentByte pdfData = pdfStamper.GetUnderContent(pageIndex);
                    //create fontsize for watermark
                    pdfData.SetFontAndSize(BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1250, BaseFont.NOT_EMBEDDED), 18);
                    //create new graphics state and assign opacity
                    PdfGState graphicsState = new PdfGState();
                    graphicsState.FillOpacity = 0.03F;
                    //set graphics state to pdfcontentbyte
                    pdfData.SetGState(graphicsState);
                    //set color of watermark
                    pdfData.SetColorFill(BaseColor.BLACK);
                    //indicates start of writing of text  
                    pdfData.BeginText();
                    //show text as per position and rotation
                    //  pdfData.ShowTextAligned(Element.ALIGN_CENTER, "Company: " + Company, pageRectangle.Width / 2, pageRectangle.Height / 2, 45);
                    pdfData.ShowTextAligned(Element.ALIGN_CENTER, "" + Company, pageRectangle.Width / 2, pageRectangle.Height / 2, 45);

                    pdfData.SetFontAndSize(BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1250, BaseFont.NOT_EMBEDDED), 8);
                    PdfGState graphicsStateText = new PdfGState();
                    graphicsStateText.FillOpacity = 0.3F;
                    //set graphics state to pdfcontentbyte
                    pdfData.SetGState(graphicsStateText);
                    //set color of watermark
                    pdfData.SetColorFill(BaseColor.BLACK);

                    //====================Working code =======================//
                    pdfData.ShowTextAligned(Element.ALIGN_TOP, " " + TransactionId, 32, 760, 0);
                    pdfData.ShowTextAligned(Element.ALIGN_TOP, " " + DateDelivered, 32, 752, 0);
                    pdfData.ShowTextAligned(Element.ALIGN_TOP, " " + Licensee, 32, 744, 0);
                    pdfData.ShowTextAligned(Element.ALIGN_TOP, " " + Company, 32, 736, 0);
                    //====================Working code =======================//

                    //====================For Testing Purpose code =======================//
                    //pdfData.ShowTextAligned(Element.ALIGN_TOP, "Transaction:" + TransactionId , 340, 760, 0);
                    //pdfData.ShowTextAligned(Element.ALIGN_TOP, "Date delivered: " + DateDelivered, 340, 752, 0);
                    //pdfData.ShowTextAligned(Element.ALIGN_TOP, "Licensee: " + Licensee, 340, 744,0);
                    //pdfData.ShowTextAligned(Element.ALIGN_TOP, "Company: " + Company, 340, 736, 0);
                    //====================For Testing Purpose code =======================//


                    pdfData.SetFontAndSize(BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1250, BaseFont.NOT_EMBEDDED), 26);
                    PdfGState graphicsStateSide = new PdfGState();
                    graphicsStateSide.FillOpacity = 0.1F;
                    //set graphics state to pdfcontentbyte
                    pdfData.SetGState(graphicsStateSide);
                    pdfData.ShowTextAligned(Element.ALIGN_TOP, Company, 580, 280, 90);
                    // pdfData.ShowTextAligned(Element.ALIGN_TOP, "www.BizAcumen.com", 580, 280, 90);
                    //call endText to invalid font set
                    pdfData.EndText();
                }
                //close stamper and output filestream
                pdfStamper.Close();
                stream.Close();
                return "Done";
            }
            catch (Exception E)
            {
                // LblMsg.Text = E.Message;
                return E.Message;
            }
        }
        public String StampNDNCAPDF(String TransactionId, String DateDelivered, String Licensee, String Company, String MCPReport)
    {
        try
        {
            PdfReader pdfReader = new PdfReader(MCPReport);
            //create stream of filestream or memorystream etc. to create output file
            //  FileStream stream = new FileStream( "/output1.pdf", FileMode.OpenOrCreate);
            FileStream stream = new FileStream( MCPReport.Replace(".pdf","out.pdf"), FileMode.OpenOrCreate);
            //create pdfstamper object which is used to add addtional content to source pdf file
            PdfStamper pdfStamper = new PdfStamper(pdfReader, stream);
            //iterate through all pages in source pdf
            for (int pageIndex = 1; pageIndex <= pdfReader.NumberOfPages; pageIndex++)
            {
                //Rectangle class in iText represent geomatric representation... in this case, rectanle object would contain page geomatry
                iTextSharp.text.Rectangle pageRectangle = pdfReader.GetPageSizeWithRotation(pageIndex);
                //pdfcontentbyte object contains graphics and text content of page returned by pdfstamper
                PdfContentByte pdfData = pdfStamper.GetUnderContent(pageIndex);
                //create fontsize for watermark
                pdfData.SetFontAndSize(BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1250, BaseFont.NOT_EMBEDDED), 18);
                //create new graphics state and assign opacity
                PdfGState graphicsState = new PdfGState();
                graphicsState.FillOpacity = 0.03F;
                //set graphics state to pdfcontentbyte
                pdfData.SetGState(graphicsState);
                //set color of watermark
                pdfData.SetColorFill(BaseColor.BLACK);
                //indicates start of writing of text
                pdfData.BeginText();
                //show text as per position and rotation
                //  pdfData.ShowTextAligned(Element.ALIGN_CENTER, "Company: " + Company, pageRectangle.Width / 2, pageRectangle.Height / 2, 45);
                pdfData.ShowTextAligned(Element.ALIGN_CENTER, "" + Company, pageRectangle.Width / 2, pageRectangle.Height / 2, 45);

                pdfData.SetFontAndSize(BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1250, BaseFont.NOT_EMBEDDED), 8);
                PdfGState graphicsStateText = new PdfGState();
                graphicsStateText.FillOpacity = 0.3F;
                //set graphics state to pdfcontentbyte
                pdfData.SetGState(graphicsStateText);
                //set color of watermark
                pdfData.SetColorFill(BaseColor.BLACK);
                // pdfData.ShowTextAligned(Element.ALIGN_TOP, "Transaction:" + TransactionId, 32, 760, 0);
            //////////////    pdfData.ShowTextAligned(Element.ALIGN_TOP, "" + TransactionId, 32, 760, 0);
            //////////////    pdfData.ShowTextAligned(Element.ALIGN_TOP, "Date delivered: " + DateDelivered, 32, 752, 0);
                pdfData.ShowTextAligned(Element.ALIGN_TOP, "( " + Licensee + " )", 75, 30, 0);
                // pdfData.ShowTextAligned(Element.ALIGN_TOP, "Company: " + Company, 32, 736, 0);
                //  pdfData.ShowTextAligned(Element.ALIGN_TOP, " " + Company, 32, 736, 0);

                pdfData.SetFontAndSize(BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1250, BaseFont.NOT_EMBEDDED), 26);
                PdfGState graphicsStateSide = new PdfGState();
                graphicsStateSide.FillOpacity = 0.1F;
                //set graphics state to pdfcontentbyte
                pdfData.SetGState(graphicsStateSide);
           ////////     pdfData.ShowTextAligned(Element.ALIGN_TOP, "www.StrategyR.com", 580, 280, 90);
                //call endText to invalid font set
                pdfData.EndText();
            }
            //close stamper and output filestream
            pdfStamper.Close();
            stream.Close();
            return "Done";
        }
        catch (Exception E)
        {
            // LblMsg.Text = E.Message;
            return E.Message;
        }
    }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
           // this.KeyDown += new KeyEventHandler(Form1_KeyDown);
        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
           
            string StampCode = "";
            string value = "";
            string filepath = ""; // = @"D:\MCPS\PCP\";
            string ExcelFilePath = "";



            filepath = txtSourceFolder.Text ;
            ExcelFilePath = txtExcelFile.Text ;
            if ((filepath == "") || (ExcelFilePath == ""))
            {

                MessageBox.Show("Please select  File path and Excel file");
               
                    BtnSource.Focus();  
               
                if ((!filepath.Equals("")) && (ExcelFilePath == ""))
                { BtnExcelSelect.Focus(); }

            }
            else
            {
                BtnStart.Enabled = false; 
                //if (InputBox("Please enter PDF File Path", "Folder Path:", ref value) == DialogResult.OK)
                //{
                //    filepath = value;
                //}
                //if (InputBox("Please enter Excel File Path and  file name", "Folder Path:", ref value) == DialogResult.OK)
                //{
                //    ExcelFilePath = value;
                //}
                string[] totfiles = Directory.GetFiles(filepath, "*.pdf");
                int stsCount = totfiles.Count();
                Debug.Flush();
                int i = 0;
                decimal totcountper = decimal.Divide(100, stsCount); //  0.340136; // Convert.ToInt16(100 / stsCount);
                foreach (string file in Directory.EnumerateFiles(filepath, "*.pdf"))
                {
                    Debug.Print(file);
                    // fileCode = file.Replace(filepath + @"\", "").Replace("toc.doc", "");
                    string con = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ExcelFilePath + "; Extended Properties='Excel 12.0 Xml;HDR=Yes;'";
                    using (OleDbConnection connection = new OleDbConnection(con))
                    {
                        if (connection.State == ConnectionState.Closed)
                        {
                            connection.Open();
                        }
                        OleDbCommand command = new OleDbCommand("select * from [Sheet1$] where PDFfile='" + file.Replace(filepath + "\\", "") + "'", connection);
                        // OleDbCommand command = new OleDbCommand("select mcp_abstracts from [Sheet1$]", connection);
                        using (OleDbDataReader dr = command.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                StampCode = dr[2].ToString();
                                Debug.Print(dr[2].ToString());
                                StampPDFReport(StampCode, DateTime.Now.ToString()  , txtName.Text , TxtCompany.Text, file);
                                //  Console.WriteLine(row1Col0);
                            }
                        }
                        connection.Close();
                    }

                    i++;

                }
                
                MessageBox.Show("Process completed successfully.");
                BtnStart.Enabled = true;
            }
           
        }

        private void BtnSource_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            txtSourceFolder.Text = folderBrowserDialog1.SelectedPath; 
        }

        private void BtnExcelSelect_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            txtExcelFile.Text = openFileDialog1.FileName;  
        }

        private void button1_Click(object sender, EventArgs e)
        {
           this.Close(); 
        }

        private void BtnSource_MouseHover(object sender, EventArgs e)
        {
            ToolTip t1 = new ToolTip();
            t1.SetToolTip(BtnSource,"Please click here to select PDF folder." );
           // t1.Show("Please click to select PDF folder", BtnSource);   
        }

        private void BtnExcelSelect_MouseHover(object sender, EventArgs e)
        {
            ToolTip t1 = new ToolTip();
            t1.SetToolTip(BtnExcelSelect, "Please click here to select Excel file.");
        }

       

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.ToString() == "F1")
            {
               Form HlpForm = new FormHelp();
           //    this.MdiParent = this;
                HlpForm.Show();  
                //MessageBox.Show(e.KeyCode.ToString());
            }

        }

       

    }
}
